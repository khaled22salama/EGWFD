#define _CRT_SECURE_NO_WARNINGS 1

#include "app.h"
#include "..\Card\card.h"
#include "..\Terminal\terminal.h"
#include "..\Server\server.h"

#include <stdio.h>
#include <string.h>

void appStart(void)
{
	ST_transaction_t transaction;
	ST_transaction_t* transactionptr = &transaction;

	setMaxAmount(&(transactionptr->terminalData), 20000);
	

	uint8_t test;
	test = 'y';
	
	

	do
	{
		
		getTransactionDate(&(transactionptr->terminalData));
		
		recieveTransactionData(transactionptr);
		uint32_t i = 0;
		for (i = 0; i < 255; i++)
		{
			if ((strcmp(transactionptr->cardHolderData.primaryAccountNumber, acount_db[i].primaryAccountNumber) == 0) && isCardExpired(transactionptr->cardHolderData, transactionptr->terminalData) == OK_t)
			{
				printf("%s\t\t%f\n", acount_db[i].primaryAccountNumber, acount_db[i].balance);
				printf("number of transaction: %d\n", order - 1);
			}
		}

		uint8_t c;
		printf("Do you want to show transaction details (y/n) : ");
		scanf(" %c", &c);

		if (c == 'y')
		{
			uint32_t number;
			printf("Enter the sequence of the transaction: ");
			scanf("%d", &number);

			getTransaction(number, trans_db);
		}

		printf("\n\nDo you want to make another transaction?\n(y/n): ");
		scanf(" %c", &test);
	} while (test == 'y');

	
}