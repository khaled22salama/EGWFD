#ifndef APPLICATION_H_INCLUDED
#define APPLICATION_H_INCLUDED
//start app
void appStart(void);


#endif // APPLICATION_H_INCLUDED
