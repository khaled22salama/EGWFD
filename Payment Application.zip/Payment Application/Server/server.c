#define _CRT_SECURE_NO_WARNINGS 1

#include "server.h"
#include <string.h>



uint32_t key = 0;
uint32_t freq = 0;
uint32_t order = 100;


//global array with data
ST_accountsDB_t acount_db[255] = {
    {9000, "6250941006528599"},
    {500, "60115564485789458"},
    {300.5, "6011000991300009"},
    {30000, "1234567890123456"}
};

ST_transaction_t trans_db[255];

void pop_db(ST_transaction_t* transactionDB, uint32_t size)
{
    uint32_t i = 0;
    for (i = 0; i < size; i++)
    {
        strcpy(transactionDB[i].cardHolderData.cardExpirationDate, "000");
        strcpy(transactionDB[i].cardHolderData.cardHolderName, "000");
        strcpy(transactionDB[i].cardHolderData.primaryAccountNumber, "000");

        strcpy(transactionDB[i].terminalData.transactionDate, "000");

        transactionDB[i].terminalData.maxTransAmount = 0;
        transactionDB[i].terminalData.transAmount = 0;

        transactionDB[i].transactionSequenceNumber = 0;
        transactionDB[i].transState = 0;
    }
}

EN_transState_t recieveTransactionData(ST_transaction_t* transData)
{
    uint8_t valid_card;
    uint8_t valid_amount;
    uint8_t saved;

    valid_card = isValidAccount(&(transData->cardHolderData));
    valid_amount = isAmountAvailable(&(transData->terminalData));
    //chack if card is expired

    if (isCardExpired(transData->cardHolderData, transData->terminalData) == EXPIRED_CARD)
    {
        puts("Card is expired");
        return DECLINED_STOLEN_CARD;
    }
    //check acount is valid or not
    if (valid_card == ACCOUNT_NOT_FOUND)
    {
        transData->transState = DECLINED_STOLEN_CARD;
    }
    //chaeck amount of money 
    else if (valid_amount == LOW_BALANCE)
    {
        transData->transState = DECLINED_INSUFFECIENT_FUND;
    }
    else
    {
        transData->transState = APPROVED;
    }
    transData->transactionSequenceNumber = order;

    saved = saveTransaction(transData);

    

    if ((valid_card == ACCOUNT_NOT_FOUND) || (freq == 255))
    {
        printf("Stolen Card\n");

        return DECLINED_STOLEN_CARD;
    }
    else if ((valid_card == OK) && (freq != 255))
    {
        if (valid_amount == LOW_BALANCE)
        {
            printf("Low balance INSUFFECIENT FUND\n");
            return DECLINED_INSUFFECIENT_FUND;
        }
        else if (saved == SAVING_FAILED)
        {
            printf("Internal Server Error\n");
            return INTERNAL_SERVER_ERROR;
        }
        else if ((isBelowMaxAmount(&(transData->terminalData)) == OK_t) && (valid_card == OK_c))
        {

            acount_db[freq].balance -= transData->terminalData.transAmount;
            printf("Succeeded\n");
        }
    }
    
    

    return APPROVED;
}

EN_serverError_t isValidAccount(ST_cardData_t* cardData)
{
    uint8_t valid_name;
    uint8_t valid_PAN;
    uint8_t valid_date;

    valid_name = getCardHolderName(cardData);
    
    while (valid_name == WRONG_NAME)
    {
        valid_name = getCardHolderName(cardData);
    }

    valid_PAN = getCardPAN(cardData);

    while (valid_PAN == WRONG_PAN)
    {
        valid_PAN = getCardPAN(cardData);
    }

    valid_date = getCardExpiryDate(cardData);

    while (valid_date == WRONG_EXP_DATE)
    {
        valid_date = getCardExpiryDate(cardData);
    }

    if ((valid_name == OK_c) && (valid_PAN == OK_c) && (valid_date == OK_c))
    {
        uint32_t i = 0;
        for (i = 0; i <255; i++)
        {
            if (strcmp(cardData->primaryAccountNumber, acount_db[i].primaryAccountNumber) == 0)
            {
                freq = i;
                return OK;
            }
        }
        freq = 255;
    }
    return ACCOUNT_NOT_FOUND;
}

EN_serverError_t isAmountAvailable(ST_terminalData_t* termData)
{
    uint8_t valid_amount;

    valid_amount = getTransactionAmount(termData);

    if (valid_amount == OK_t)
    {
        if (termData->transAmount > acount_db[freq].balance)
        {
            return LOW_BALANCE;
        }

        return OK;
    }
}

EN_serverError_t saveTransaction(ST_transaction_t* transData)
{
    uint32_t i = order - 100;
    
    if (i >= 255)
    {
        return SAVING_FAILED;
    }

    strcpy(trans_db[i].cardHolderData.cardExpirationDate, transData->cardHolderData.cardExpirationDate);
    strcpy(trans_db[i].cardHolderData.cardHolderName, transData->cardHolderData.cardHolderName);
    strcpy(trans_db[i].cardHolderData.primaryAccountNumber, transData->cardHolderData.primaryAccountNumber);

    strcpy(trans_db[i].terminalData.transactionDate, transData->terminalData.transactionDate);

    trans_db[i].terminalData.maxTransAmount = transData->terminalData.maxTransAmount;
    trans_db[i].terminalData.transAmount = transData->terminalData.transAmount;

    trans_db[i].transactionSequenceNumber = transData->transactionSequenceNumber;
    trans_db[i].transState = transData->transState;

    order++;

    return OK;
}

EN_serverError_t getTransaction(uint32_t transactionSequenceNumber, ST_transaction_t* transData)
{
    uint32_t i = 0;
    while (transData[i].transactionSequenceNumber != 0)
    {
        if (transData[i].transactionSequenceNumber == transactionSequenceNumber)
        {
            puts("****************************************");
            puts("Transaction Details:");
            printf("Card Holder Name  :\t\t%s\n", transData[i].cardHolderData.cardHolderName);
            printf("Card PAN    :\t\t%s\n", transData[i].cardHolderData.primaryAccountNumber);
            printf("Card Expiration Date :\t\t%s\n", transData[i].cardHolderData.cardExpirationDate);
            puts("-------------------------");
            printf("Transaction Date  :\t\t%s\n", transData[i].terminalData.transactionDate);
            printf("Transaction Amount :\t\t%f\n", transData[i].terminalData.transAmount);
            printf("Transaction Maximum Amount:\t\t%f\n", transData[i].terminalData.maxTransAmount);

            printf("Sequence Number  :\t\t%d\n", transData[i].transactionSequenceNumber);
            printf("Transaction State  :\t\t%d\n", transData[i].transState);

            return OK;
        }
        i++;
    }
    puts("Transaction Not Found");
    return TRANSACTION_NOT_FOUND;
}