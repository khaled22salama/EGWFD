#define _CRT_SECURE_NO_WARNINGS 1

#include "terminal.h"
#include <stdio.h>
#include <time.h>

EN_terminalError_t getTransactionDate(ST_terminalData_t* termData)
{
	time_t ddtim;
	struct tm* cd_date;

	//get system time for transaction date
	time(&ddtim);

	cd_date = localtime(&ddtim);

	
	sprintf(termData->transactionDate, "%02d/%02d/%04d", cd_date->tm_mday, cd_date->tm_mon + 1, cd_date->tm_year + 1900);
	

	return OK_t;
}

EN_terminalError_t isCardExpired(ST_cardData_t cardData, ST_terminalData_t termData)
{
	//know expire date
    uint8_t* ex_year = &(cardData.cardExpirationDate[3]);
    uint8_t* ex_month = &(cardData.cardExpirationDate[0]);

	//get transcition date
	uint8_t* terminal_year = &(termData.transactionDate[8]);
	uint8_t* terminal_month = &(termData.transactionDate[3]);
    
	uint32_t ex_date = 100 * atoi(ex_year) + atoi(ex_month);
    uint32_t terminal_date = 100 * atoi(terminal_year) + atoi(terminal_month);

	//compare between two date
	if (ex_date < terminal_date)
	{
		return EXPIRED_CARD;
	}

	return OK_t;
}

EN_terminalError_t getTransactionAmount(ST_terminalData_t* termData)
{
	printf("Please Enter the transaction Amount: ");
	scanf("%f", &(termData->transAmount));

	if (termData->transAmount <= 0)
	{
		return INVALID_AMOUNT;
	}

	return OK_t;
}

EN_terminalError_t isBelowMaxAmount(ST_terminalData_t* termData)
{
	if (termData->transAmount > termData->maxTransAmount)
	{
		printf("Exceeded maximum amount\n");
		return EXCEED_MAX_AMOUNT;
	}

	return OK_t;
}

EN_terminalError_t setMaxAmount(ST_terminalData_t* termData, float max)
{
	if (max <= 0)
	{
		return INVALID_MAX_AMOUNT;
	}

	termData->maxTransAmount = max;
	return OK_t;
}