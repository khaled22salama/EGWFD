#ifndef TYPES_H_INCLUDED
#define TYPES_H_INCLUDED

typedef char uint8_t;
typedef int uint32_t;
typedef unsigned long long uint64_t;

#endif // TYPES_H_INCLUDED
